Semaforo.h


Libreria para el entorno Arduino para controlar semaforos tipo RENFE en la maqueta.

Incluye tambien la se�alizacion basica de la DB (Semaforos tipo HP)


Surge como un hilo sobre "Nociones basicas para programar en C del Arduino o entender los listados", en el foro CTMS (Control Tren Modelo por Software) http://ctms1.com/ 


Se ha trasladado el contenido de ese hilo en forma de libro pensando en los aficionados al modelismo ferroviario que desean acercarse a la programacion de Arduino para aplicarlo en sus maquetas.


El libro electronico puede descargarse desde https://usuaris.tinet.cat/fmco/cgi-bin/download.cgi?file=download/Lenguaje_de_programacion_Arduino.pdf

La libreria esta en formato .zip en https://usuaris.tinet.cat/fmco/cgi-bin/download.cgi?file=download/Semaforo.zip



Paco Ca�ada
https://usuaris.tinet.cat/fmco/